import os
import json
import boto3
import pymysql
import subprocess
import urllib.parse
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3 = boto3.client('s3')

def get_video_info(path):
    """ffprobe를 사용하여 영상의 메타데이터를 추출합니다."""
    try:
        cmd = [
            'ffprobe', '-v', 'error', 
            '-show_entries', 'format=duration', 
            '-show_entries', 'stream=width,height', 
            '-of', 'json', path
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        data = json.loads(result.stdout)
        
        video_stream = next(s for s in data['streams'] if s['codec_type'] == 'video')
        duration = float(data['format']['duration'])
        resolution = f"{video_stream['width']}x{video_stream['height']}"
        
        return {
            "duration": int(duration), 
            "resolution": resolution
        }
    except Exception as e:
        logger.error(f"메타데이터 추출 실패: {str(e)}")
        return None

def handler(event, context):
    DB_HOST = os.environ.get('DB_HOST')
    DB_USER = os.environ.get('DB_USER')
    DB_PASS = os.environ.get('DB_PASSWORD')
    DB_NAME = os.environ.get('DB_NAME')

    video_local = ""
    thumb_local = ""

    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])
        
        filename = os.path.basename(key)
        
        try:
            content_id = int(filename.split('_')[0])
        except (ValueError, IndexError):
            logger.warning(f"파일명에서 content_id를 추출할 수 없습니다: {filename}. 기본값 1을 사용합니다.")
            content_id = 1 

        video_local = f"/tmp/{filename}"
        thumb_name = f"thumb_{filename.rsplit('.', 1)[0]}.jpg"
        thumb_local = f"/tmp/{thumb_name}"

        logger.info(f"영상 처리 시작: {key}")
        s3.download_file(bucket, key, video_local)

        video_meta = get_video_info(video_local)
        duration = video_meta['duration'] if video_meta else 0
        resolution = video_meta['resolution'] if video_meta else "unknown"

        subprocess.run([
            'ffmpeg', '-y', '-i', video_local, 
            '-ss', '00:00:05', '-vframes', '1', thumb_local
        ], check=True)

        thumb_key = f"thumbnails/{thumb_name}"
        s3.upload_file(thumb_local, bucket, thumb_key)

        video_uri = f"s3://{bucket}/{key}"
        thumb_uri = f"s3://{bucket}/{thumb_key}"

        conn = pymysql.connect(
            host=DB_HOST, user=DB_USER, password=DB_PASS, db=DB_NAME,
            connect_timeout=10
        )
        
        with conn.cursor() as cursor:
            sql = """
                INSERT INTO video_assets 
                (content_id, video_url, thumbnail_url, duration, resolution)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (
                content_id,
                video_uri,
                thumb_uri,
                duration,
                resolution
            ))
            conn.commit()
        conn.close()

        logger.info(f"성공: {key} 등록 완료 (content_id: {content_id})")
        return {"status": "success", "content_id": content_id}

    except Exception as e:
        logger.error(f"영상 처리 중 에러 발생: {str(e)}")
        raise e
    finally:
        for f in [video_local, thumb_local]:
            if f and os.path.exists(f):
                os.remove(f)
